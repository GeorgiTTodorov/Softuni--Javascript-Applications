function attachEvents() {
    const textArea = document.getElementById('messages');
    document.getElementById('submit').addEventListener('click', postData);
    document.getElementById('refresh').addEventListener('click', getData);
    const url = 'http://localhost:3030/jsonstore/messenger';

    async function getData() {
        try {
            textArea.textContent = '';
        const response = await fetch(url);
        if (!response.ok) throw new Error('Érror');
        const data = await response.json();
        
        Object.values(data).forEach(el => {
            textArea.textContent += `${el.author}: ${el.content}\n`
        })  
    } catch(err) {
        alert(err);
        } 
    }

    async function postData () {
        const name = document.querySelector('[name="author"]');
        const message = document.querySelector('[name="content"]');
        if (!name.value || !message.value) return; 

        try {
        const res = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-type': 'application/json'
            },
            body: JSON.stringify({
                author: name.value,
                content: message.value
            })
        });
        if (!res.ok) throw new Error('Error') 
        const dta = await res.json();
        
        } catch (err) {
            alert(err);
        }
    }
}

attachEvents();